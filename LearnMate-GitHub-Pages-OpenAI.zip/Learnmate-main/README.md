# LearnMate AI — GitHub Pages + OpenAI-ready full project

LearnMate is a React + Vite + TypeScript frontend with an Express backend. The tutor uses OpenAI through server-side requests; the OpenAI secret is never sent to the browser.

## Important hosting detail

GitHub Pages can host **only the static frontend**. It cannot run Express, authentication routes, curriculum APIs, assessment APIs, or OpenAI calls. For the full application, deploy this repository's backend to a Node.js host (for example, Render) and deploy the frontend to GitHub Pages. The frontend connects to the backend using `VITE_API_BASE_URL`.

If you prefer the simplest full-stack deployment, deploy the entire project to a Node.js host and use the same-origin setup; then you do not need GitHub Pages for the app itself.

## Local development

Requirements: Node.js 22 or newer and npm.

1. Install packages: `npm install`
2. Copy `.env.example` to `.env`.
3. Put your OpenAI key in `.env` as `OPENAI_API_KEY=...`. Never commit `.env`.
4. Start the app: `npm run dev`
5. Open `http://localhost:3000`.

## OpenAI configuration (backend only)

- `OPENAI_API_KEY` — required for live AI responses; keep secret.
- `OPENAI_CHAT_MODEL` — defaults to `gpt-4.1-mini`.
- `OPENAI_TTS_MODEL` — defaults to `gpt-4o-mini-tts`.
- `OPENAI_TTS_VOICE` — defaults to `alloy`.
- `PORT` — defaults to `3000`.
- `CORS_ALLOWED_ORIGINS` — exact comma-separated origins allowed to call the API from another origin, e.g. `https://your-user.github.io`. Do not use `*` for a credentialed/private app.

The key must be set in the backend host's secret environment-variable settings, not in GitHub Pages, not in a `VITE_` variable, and not in any frontend source file. If you have already shared a real key publicly, revoke it and create a replacement.

## Deploy backend to Render

1. Push this repository to GitHub (without `.env`).
2. In Render, create a **Web Service** from the repository.
3. Build command: `npm install && npm run build`
4. Start command: `npm start`
5. Add environment variables: `NODE_ENV=production`, `OPENAI_API_KEY` (secret), and optionally model settings.
6. Note the deployed service URL, such as `https://your-service.onrender.com`.
7. Add `CORS_ALLOWED_ORIGINS` with your GitHub Pages origin, such as `https://your-user.github.io` (origin only; no repository path).
8. Verify `https://your-service.onrender.com/api/health` returns JSON.

A `render.yaml` is included as a starting point. Check your hosting provider's dashboard and logs after deployment.

## Deploy frontend to GitHub Pages

A GitHub Actions workflow is included at `.github/workflows/deploy-pages.yml`.

1. Push the project to the repository's `main` branch.
2. In GitHub, open **Settings → Pages** and set the build/deployment source to **GitHub Actions**.
3. Open **Settings → Secrets and variables → Actions → Variables** and create a repository variable named `VITE_API_BASE_URL`. Set it to the backend origin, e.g. `https://your-service.onrender.com` (no trailing slash). This is a public API URL, not a secret.
4. Push a commit or manually run the workflow from **Actions**.
5. Open the Pages URL shown in the workflow deployment.

For a repository named `Learnmate-main`, the default project URL is typically `https://YOUR-USERNAME.github.io/Learnmate-main/`. The workflow sets the Vite base path automatically. If using a custom domain, set `PAGES_BASE_PATH=/` in the workflow build environment.

## Build checks

```bash
npm install
npm run build
npm start
```

After starting the production server, verify `/api/health`. Also check browser DevTools → Console and Network if the page is blank.

## Notes

- The application still needs end-to-end testing in your environment; this archive is prepared for deployment but has not been certified as production-ready.
- Demo authentication/database behavior should not be treated as production-grade storage for real student records. Add persistent storage, rate limiting, monitoring, and privacy controls before a public launch.
