/**
 * Central API helper. On a single-origin Node deployment, leave VITE_API_BASE_URL empty.
 * For GitHub Pages, set VITE_API_BASE_URL to the HTTPS URL of the separately hosted API.
 */
const configuredBase = (import.meta.env.VITE_API_BASE_URL || '').trim();
const API_BASE = configuredBase.replace(/\/$/, '');

export function apiFetch(input: string | URL, init?: RequestInit): Promise<Response> {
  const raw = input.toString();
  const path = raw.startsWith('/') ? raw : `/${raw}`;
  const target = API_BASE ? `${API_BASE}${path}` : path;
  return fetch(target, init);
}
