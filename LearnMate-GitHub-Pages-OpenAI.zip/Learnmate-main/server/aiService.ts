import { db } from './db.js';
import { RobotEmotion, WhiteboardData } from '../src/types/index.js';
import { generateSelfCreatedContent } from '../src/utils/contentGenerator.js';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY?.trim();
const OPENAI_BASE_URL = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
const OPENAI_CHAT_MODEL = process.env.OPENAI_CHAT_MODEL || 'gpt-4.1-mini';
const OPENAI_TTS_MODEL = process.env.OPENAI_TTS_MODEL || 'gpt-4o-mini-tts';
const OPENAI_TTS_VOICE = process.env.OPENAI_TTS_VOICE || 'alloy';

export interface TutorResponsePayload {
  robotResponseText: string;
  robotEmotion: RobotEmotion;
  whiteboard: WhiteboardData;
  suggestedFollowUps: string[];
  groundedNoteTitle?: string;
  audioBase64?: string;
}

function getGroundedContext(note: ReturnType<typeof db.getNoteById>, subject: string): string {
  if (!note) return `SUBJECT: ${subject || 'general STEM'}\nNo matching curriculum note was found. Explain accurately and state uncertainty when needed.`;
  return `AUTHORITATIVE CURRICULUM NOTE TITLE: "${note.title}"\nSUBJECT: ${note.subject}\nSUMMARY: ${note.summary}\nKEY FORMULAS: ${note.keyFormulas.join(', ')}\nDETAILED CONTENT:\n${note.contentMarkdown}`;
}

async function openAIChat(prompt: string, systemInstruction: string): Promise<string> {
  if (!OPENAI_API_KEY) throw new Error('OPENAI_API_KEY is not configured. Add it to the server environment.');
  const response = await fetch(`${OPENAI_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${OPENAI_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: OPENAI_CHAT_MODEL,
      temperature: 0.4,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: systemInstruction },
        { role: 'user', content: prompt },
      ],
    }),
    signal: AbortSignal.timeout(45_000),
  });
  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    throw new Error(`OpenAI chat request failed (${response.status}): ${detail.slice(0, 500)}`);
  }
  const payload = await response.json() as { choices?: Array<{ message?: { content?: string | null } }> };
  const content = payload.choices?.[0]?.message?.content;
  if (!content) throw new Error('OpenAI returned an empty response.');
  return content;
}

export async function askAITutor(prompt: string, subject: string, currentNoteId?: string): Promise<TutorResponsePayload> {
  let groundedNote = currentNoteId ? db.getNoteById(currentNoteId, 'student') : undefined;
  if (!groundedNote) {
    const searchResults = db.searchGroundedNotes(prompt, subject);
    if (searchResults.length > 0) groundedNote = searchResults[0];
  }
  const groundedContext = getGroundedContext(groundedNote, subject);

  if (OPENAI_API_KEY) {
    try {
      const systemInstruction = `You are Aero, the interactive robot tutor for LearnMate AI. Be warm, precise, encouraging, and pedagogical. Teach high-school and college students step by step. Use the grounded curriculum material when relevant, but do not invent facts or claim the note says something it does not. If the question is outside the note, answer from general knowledge and flag important uncertainty.\n\nGROUNDED MATERIAL:\n${groundedContext}\n\nReturn ONLY valid JSON with this shape: {"robotResponseText":"2-4 concise, clear paragraphs suitable for speech","robotEmotion":"greeting|thinking|speaking|explaining|celebrating|curious|encouraging","whiteboard":{"title":"short title","diagramType":"equation|step_flow|comparison|interactive_model|key_takeaways","steps":[{"stepNumber":1,"title":"step title","description":"explanation"}],"formula":{"latex":"optional formula","variables":[{"symbol":"x","label":"meaning","value":"value or unit"}],"interactiveSlider":{"param":"optional parameter","label":"label","min":0,"max":10,"default":5,"unit":"optional unit"}},"comparisonData":{"headers":["A","B"],"rows":[["...","..."]] },"keyTakeaways":["takeaway"],"activity":{"id":"unique-ish id","type":"concept_check","promptQuestion":"question","hint":"hint","options":[{"id":"a","label":"option","isCorrect":true}]}},"suggestedFollowUps":["question 1","question 2","question 3"]}. Include only useful optional whiteboard fields. Use exactly three suggestedFollowUps. Ensure all JSON is valid.`;
      const raw = await openAIChat(prompt, systemInstruction);
      const parsed = JSON.parse(raw) as Partial<TutorResponsePayload>;
      const generated = generateSelfCreatedContent(groundedNote?.title || prompt, subject);
      const wb = (parsed.whiteboard || {}) as WhiteboardData;
      wb.title ||= 'Concept Breakdown';
      wb.diagramType ||= 'key_takeaways';
      wb.selfCreatedNotesMarkdown ||= generated.notesMarkdown;
      wb.selfCreatedDiagramSvg ||= generated.diagramSvg;
      wb.selfCreatedDiagramType ||= generated.diagramType;
      wb.practiceQuestions ||= generated.practiceQuestions;
      wb.audioNarrationScript ||= generated.audioNarrationScript;
      if (!wb.activity) {
        wb.activity = {
          id: `act_${Date.now()}`,
          type: 'concept_check',
          promptQuestion: `What is the most important idea to remember about ${groundedNote?.title || prompt}?`,
          hint: 'Think about the core principle or relationship explained above.',
          options: [
            { id: 'opt_1', label: 'Apply the main principle and check the assumptions.', isCorrect: true },
            { id: 'opt_2', label: 'Ignore the assumptions and guess.', isCorrect: false },
            { id: 'opt_3', label: 'Memorize the result without understanding it.', isCorrect: false },
          ],
        };
      }
      return {
        robotResponseText: typeof parsed.robotResponseText === 'string' && parsed.robotResponseText.trim() ? parsed.robotResponseText : 'Let us break this concept down step by step.',
        robotEmotion: isRobotEmotion(parsed.robotEmotion) ? parsed.robotEmotion : 'explaining',
        whiteboard: wb,
        suggestedFollowUps: Array.isArray(parsed.suggestedFollowUps) && parsed.suggestedFollowUps.length
          ? parsed.suggestedFollowUps.slice(0, 3).map(String)
          : ['Can we work through an example?', 'Where is this used in real life?', 'Can you quiz me on this concept?'],
        groundedNoteTitle: groundedNote?.title,
      };
    } catch (err) {
      console.error('OpenAI tutor request failed; using built-in fallback:', err instanceof Error ? err.message : err);
    }
  }
  return generateDeterministicTutorResponse(prompt, subject, groundedNote);
}

function isRobotEmotion(value: unknown): value is RobotEmotion {
  return ['greeting', 'thinking', 'speaking', 'explaining', 'celebrating', 'curious', 'encouraging'].includes(String(value));
}

/** Returns base64-encoded MP3 audio generated by OpenAI, or null when unavailable. */
export async function generateSpeechAudio(text: string): Promise<string | null> {
  if (!OPENAI_API_KEY) return null;
  const cleanText = text.replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 3500);
  if (!cleanText) return null;
  try {
    const response = await fetch(`${OPENAI_BASE_URL}/audio/speech`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: OPENAI_TTS_MODEL,
        voice: OPENAI_TTS_VOICE,
        input: cleanText,
        instructions: 'Speak clearly, warmly, and encouragingly as a patient educational robot tutor. Use a natural pace.',
        response_format: 'mp3',
      }),
      signal: AbortSignal.timeout(45_000),
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => '');
      console.warn(`OpenAI speech request failed (${response.status}): ${detail.slice(0, 300)}`);
      return null;
    }
    const audio = Buffer.from(await response.arrayBuffer());
    return audio.length ? audio.toString('base64') : null;
  } catch (err) {
    console.warn('OpenAI speech generation unavailable:', err instanceof Error ? err.message : err);
    return null;
  }
}

function generateDeterministicTutorResponse(
  prompt: string,
  subject: string,
  note?: ReturnType<typeof db.getNoteById>
): TutorResponsePayload {
  const p = prompt.toLowerCase();
  const generated = generateSelfCreatedContent(note?.title || prompt, subject);

  if (p.includes('projectile') || p.includes('kinematics') || p.includes('parabola') || subject === 'physics') {
    return {
      robotResponseText:
        "Let's break down 2D projectile motion! The core principle discovered by Galileo is that horizontal and vertical motions are completely independent. Horizontally, there is zero acceleration so velocity remains constant. Vertically, Earth's gravity accelerates the object downwards at 9.81 m/s². I have self-created complete notes, a vector diagram, auditory narration, and practice questions for you on your board!",
      robotEmotion: 'explaining',
      whiteboard: {
        title: '2D Projectile Trajectory Dynamics',
        diagramType: 'equation',
        selfCreatedNotesMarkdown: generated.notesMarkdown,
        selfCreatedDiagramSvg: generated.diagramSvg,
        selfCreatedDiagramType: generated.diagramType,
        practiceQuestions: generated.practiceQuestions,
        audioNarrationScript: generated.audioNarrationScript,
        formula: {
          latex: 'R = \\frac{v_0^2 \\sin(2\\theta)}{g}',
          variables: [
            { symbol: 'v_0', label: 'Initial Launch Velocity', value: '25 m/s' },
            { symbol: '\\theta', label: 'Launch Angle', value: '45°' },
            { symbol: 'g', label: 'Gravitational Constant', value: '9.81 m/s²' },
            { symbol: 'R', label: 'Horizontal Range', value: '63.7 m' },
          ],
          interactiveSlider: {
            param: '\\theta',
            label: 'Launch Angle (\\theta)',
            min: 15,
            max: 75,
            default: 45,
            unit: '°',
          },
        },
        steps: [
          { stepNumber: 1, title: 'Velocity Decomposition', description: 'Split vector: v_x = v_0 * cos(θ), v_y = v_0 * sin(θ)' },
          { stepNumber: 2, title: 'Apex Peak Time', description: 'Vertical velocity reaches 0 at t_peak = (v_0 * sin(θ)) / g' },
          { stepNumber: 3, title: 'Total Horizontal Range', description: 'Multiply horizontal speed by total time: R = v_x * (2 * t_peak)' },
        ],
        keyTakeaways: [
          'Horizontal velocity remains invariant throughout flight.',
          'The maximum ground range is achieved at an angle of exactly 45° in vacuum.',
          'Flight duration depends strictly on vertical launch velocity component.',
        ],
        activity: {
          id: 'act_proj_1',
          type: 'concept_check',
          promptQuestion: 'Aero asks: At what launch angle is the horizontal ground range strictly maximized for a projectile launched on flat terrain?',
          hint: 'Think about when sin(2θ) reaches its maximum mathematical value of 1.0! At what 2θ is sin(2θ) = 1?',
          options: [
            { id: 'opt_1', label: '30° — Flatter trajectory preserves forward velocity longer', isCorrect: false },
            { id: 'opt_2', label: '45° — Perfectly balances vertical hang time and horizontal speed', isCorrect: true },
            { id: 'opt_3', label: '60° — High angle provides superior hang time in the air', isCorrect: false },
            { id: 'opt_4', label: '90° — Launching straight up gives maximum height', isCorrect: false },
          ],
        },
      },
      suggestedFollowUps: [
        'How does air resistance deform the trajectory shape?',
        'Why does a 30° launch achieve the exact same range as a 60° launch?',
        'What happens if the projectile lands higher than launch height?',
      ],
      groundedNoteTitle: note?.title || 'Kinematics: 2D Projectile Motion & Vector Decomposition',
    };
  }

  if (p.includes('quadratic') || p.includes('discriminant') || subject === 'mathematics') {
    return {
      robotResponseText:
        "Let's explore quadratic functions! The discriminant Δ = b² - 4ac tells us everything about the roots before we even solve the equation. When Δ is positive, the parabola slices through the x-axis at two distinct points. When Δ is zero, it kisses the axis at a single vertex. I have self-created reading notes, a parabola diagram, auditory audio, and practice questions below!",
      robotEmotion: 'thinking',
      whiteboard: {
        title: 'Quadratic Discriminant Invariants',
        diagramType: 'equation',
        selfCreatedNotesMarkdown: generated.notesMarkdown,
        selfCreatedDiagramSvg: generated.diagramSvg,
        selfCreatedDiagramType: generated.diagramType,
        practiceQuestions: generated.practiceQuestions,
        audioNarrationScript: generated.audioNarrationScript,
        formula: {
          latex: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}',
          variables: [
            { symbol: 'a', label: 'Quadratic Curvature Coefficient', value: '1' },
            { symbol: 'b', label: 'Linear Slope Coefficient', value: '-4' },
            { symbol: 'c', label: 'Constant Y-Intercept', value: '3' },
            { symbol: '\\Delta', label: 'Discriminant (b² - 4ac)', value: '4' },
          ],
          interactiveSlider: {
            param: 'c',
            label: 'Vertical Shift (c)',
            min: -5,
            max: 10,
            default: 3,
            unit: '',
          },
        },
        steps: [
          { stepNumber: 1, title: 'Calculate Discriminant', description: 'Evaluate Δ = b² - 4ac to check root topology' },
          { stepNumber: 2, title: 'Locate Axis of Symmetry', description: 'The vertex x-coordinate is always x = -b / (2a)' },
          { stepNumber: 3, title: 'Compute Symmetrical Roots', description: 'Add and subtract √(Δ) / (2a) from the central axis' },
        ],
        keyTakeaways: [
          'Δ > 0: Two real distinct roots',
          'Δ = 0: Single double root at vertex',
          'Δ < 0: Complex conjugate root pair',
        ],
        activity: {
          id: 'act_quad_1',
          type: 'concept_check',
          promptQuestion: 'Aero asks: If the discriminant Δ = b² - 4ac is exactly equal to 0, what does this tell us about the roots?',
          hint: 'Remember the quadratic formula has ±√(Δ). If Δ is 0, adding or subtracting 0 yields the same value!',
          options: [
            { id: 'opt_1', label: 'Two distinct real roots crossing the x-axis', isCorrect: false },
            { id: 'opt_2', label: 'Exactly one real double root; the parabola touches the x-axis at its vertex', isCorrect: true },
            { id: 'opt_3', label: 'Two complex conjugate roots with non-zero imaginary parts', isCorrect: false },
            { id: 'opt_4', label: 'No solutions can exist mathematically', isCorrect: false },
          ],
        },
      },
      suggestedFollowUps: [
        'How does completing the square geometrically prove this formula?',
        'What are Vieta’s formulas for root sums and products?',
        'How does the vertex form f(x) = a(x - h)² + k relate to standard form?',
      ],
      groundedNoteTitle: note?.title || 'Quadratic Functions: Discriminants & Parabolic Invariants',
    };
  }

  // General STEM pedagogical response for WHATEVER question or chapter is asked
  return {
    robotResponseText: `I have analyzed "${note ? note.title : prompt}" and self-created custom reading notes, a visual diagram, auditory narration, and practice questions for you! Switch between the learning methods above to study the way you learn best.`,
    robotEmotion: 'greeting',
    whiteboard: {
      title: note ? note.title : prompt.slice(0, 50),
      diagramType: 'step_flow',
      selfCreatedNotesMarkdown: generated.notesMarkdown,
      selfCreatedDiagramSvg: generated.diagramSvg,
      selfCreatedDiagramType: generated.diagramType,
      practiceQuestions: generated.practiceQuestions,
      audioNarrationScript: generated.audioNarrationScript,
      steps: [
        { stepNumber: 1, title: 'System Definition', description: 'Isolate the boundary conditions and identify key variables.' },
        { stepNumber: 2, title: 'Conservation Laws', description: 'Apply governing conservation laws (energy, mass, or information invariants).' },
        { stepNumber: 3, title: 'Analytical Solution', description: 'Synthesize formulas to predict system behavior under changes.' },
      ],
      keyTakeaways: [
        note ? note.summary : `Master fundamental axioms of ${prompt.slice(0, 30)}.`,
        'Draw visual diagrams to verify your algebraic intuition.',
      ],
      activity: {
        id: 'act_stem_gen',
        type: 'concept_check',
        promptQuestion: `Aero asks: When analyzing ${note ? note.title : prompt}, why do we separate independent variables first?`,
        hint: 'Independent variables allow us to analyze orthogonal components without cross-interference.',
        options: [
          { id: 'opt_1', label: 'It simplifies equations and lets us solve each dimension independently', isCorrect: true },
          { id: 'opt_2', label: 'It eliminates the need for mathematical units', isCorrect: false },
          { id: 'opt_3', label: 'It forces all equations to be linear', isCorrect: false },
        ],
      },
    },
    suggestedFollowUps: [
      'Can you show me a step-by-step example problem?',
      'What are common misconceptions students have here?',
      'How do we test this experimentally in the laboratory?',
    ],
    groundedNoteTitle: note?.title || prompt,
  };
}
